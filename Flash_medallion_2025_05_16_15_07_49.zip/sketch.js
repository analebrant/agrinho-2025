let mensagens = [
  "No campo, o silêncio é que manda...",
  "Na cidade, o barulho nunca para!",
  "Aqui vejo estrelas todas as noites.",
  "Lá só vejo luzes de prédios...",
  "Mas ambos têm sua beleza, né?"
];
let mensagemAtual = 0;
let textoExibido = "";
let indiceLetra = 0;
let tempoProximaMensagem = 0;

function setup() {
  createCanvas(800, 400);
  textSize(20);
  textStyle(BOLD);
  fill(255);
}

function draw() {
  // Fundo: campo (esquerda) vs cidade (direita)
  desenharAmbientes();
  
  // Caixa de diálogo
  fill(0, 0, 0, 150);
  rect(50, 50, width - 100, 100, 20);
  
  // Texto sendo digitado
  fill(255);
  text(textoExibido, 70, 80, width - 140, 100);
  
  // Lógica para mostrar mensagens lentamente
  if (indiceLetra < mensagens[mensagemAtual].length) {
    textoExibido += mensagens[mensagemAtual].charAt(indiceLetra);
    indiceLetra++;
  } else if (millis() > tempoProximaMensagem) {
    proximaMensagem();
  }
}

function desenharAmbientes() {
  // Campo (lado esquerdo)
  background(135, 206, 235); // Céu
  fill(34, 139, 34);
  rect(0, height / 2, width / 2, height / 2); // Grama
  fill(139, 69, 19);
  rect(100, height / 2 - 50, 30, 50); // Árvore
  fill(0, 100, 0);
  ellipse(115, height / 2 - 50, 60, 80); // Copa da árvore
  
  // Cidade (lado direito)
  fill(50);
  for (let x = width / 2; x < width; x += 60) {
    let alt = random(50, 150);
    rect(x, height - alt, 40, alt); // Prédios
  }
  fill(255, 255, 0);
  ellipse(random(width / 2, width), random(0, height / 2), 5, 5); // Luzes
}

function proximaMensagem() {
  mensagemAtual = (mensagemAtual + 1) % mensagens.length;
  textoExibido = "";
  indiceLetra = 0;
  tempoProximaMensagem = millis() + 3000; // Espera 3 segundos
}

function mousePressed() {
  proximaMensagem(); // Clique para pular mensagem
}